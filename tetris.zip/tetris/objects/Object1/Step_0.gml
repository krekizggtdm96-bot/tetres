anim_t += delta_time / 1000000;
if (milestone_timer > 0) milestone_timer--;

if (in_settings) {
    if (keyboard_check_pressed(vk_escape) || keyboard_check_pressed(vk_tab)) {
        in_settings = false;
        exit;
    }
    if (keyboard_check_pressed(vk_left)) {
        res_index = (res_index - 1 + array_length(resolutions)) mod array_length(resolutions);
        apply_display_settings();
    }
    if (keyboard_check_pressed(vk_right)) {
        res_index = (res_index + 1) mod array_length(resolutions);
        apply_display_settings();
    }
    if (keyboard_check_pressed(vk_up)) {
        gfx_quality = (gfx_quality + 1) mod 3;
        apply_display_settings();
    }
    if (keyboard_check_pressed(vk_down)) {
        gfx_quality = (gfx_quality + 2) mod 3;
        apply_display_settings();
    }
    if (keyboard_check_pressed(ord("F"))) {
        fullscreen = !fullscreen;
        apply_display_settings();
    }
    if (keyboard_check_pressed(ord("H"))) {
        show_fps = !show_fps;
    }
    if (keyboard_check_pressed(ord("L"))) {
        lang = (lang == "ru") ? "en" : "ru";
    }
    exit;
}

if (in_menu) {
    if (keyboard_check_pressed(ord("L"))) {
        lang = (lang == "ru") ? "en" : "ru";
    }
    if (keyboard_check_pressed(vk_up)) {
        menu_sel = (menu_sel + 2) mod 3;
    }
    if (keyboard_check_pressed(vk_down)) {
        menu_sel = (menu_sel + 1) mod 3;
    }
    if (keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space)) {
        switch (menu_sel) {
            case 0:
                ds_grid_clear(grid, 0);
                score = 0;
                lines = 0;
                level = 1;
                drop_timer = 0;
                spawn_piece();
                in_menu = false;
                break;
            case 1:
                in_settings = true;
                break;
            case 2:
                game_end();
                break;
        }
    }
    exit;
}

if (keyboard_check_pressed(vk_escape) || keyboard_check_pressed(vk_tab)) {
    in_menu = true;
    exit;
}

if (keyboard_check_pressed(vk_left)) {
    if (!check_collision(cur_x - 1, cur_y, cur_shape)) cur_x--;
}
if (keyboard_check_pressed(vk_right)) {
    if (!check_collision(cur_x + 1, cur_y, cur_shape)) cur_x++;
}
if (keyboard_check_pressed(vk_up)) {
    var _rot = rotate_cw(cur_shape);
    if (!check_collision(cur_x, cur_y, _rot)) cur_shape = _rot;
}

var _interval = get_drop_interval(level);
if (keyboard_check(vk_down)) _interval *= 0.15;

drop_timer += delta_time / 1000000;
if (drop_timer >= _interval) {
    drop_timer = 0;
    if (!check_collision(cur_x, cur_y + 1, cur_shape)) {
        cur_y++;
    } else {
        for (var _r = 0; _r < 4; _r++) {
            for (var _c = 0; _c < 4; _c++) {
                if (cur_shape[_r][_c] != 0) {
                    var _gx = cur_x + _c;
                    var _gy = cur_y + _r;
                    if (_gy >= 0 && _gy < rows && _gx >= 0 && _gx < cols) {
                        grid[# _gx, _gy] = cur_color;
                    }
                }
            }
        }

        var _cleared = 0;
        for (var _row = rows - 1; _row >= 0; _row--) {
            var _full = true;
            for (var _col = 0; _col < cols; _col++) {
                if (grid[# _col, _row] == 0) {
                    _full = false;
                    break;
                }
            }
            if (_full) {
                _cleared++;
                for (var _y2 = _row; _y2 > 0; _y2--) {
                    for (var _x2 = 0; _x2 < cols; _x2++) {
                        grid[# _x2, _y2] = grid[# _x2, _y2 - 1];
                    }
                }
                for (var _x3 = 0; _x3 < cols; _x3++) grid[# _x3, 0] = 0;
                _row++;
            }
        }

        add_lines(_cleared);
        spawn_piece();

        if (check_collision(cur_x, cur_y, cur_shape)) {
            in_menu = true;
        }
    }
}