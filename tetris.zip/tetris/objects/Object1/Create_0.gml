c_gold = make_color_rgb(255, 215, 0);

resolutions = [
    [1280, 720],
    [1600, 900],
    [1920, 1080]
];
res_index   = 0;
fullscreen  = false;
gfx_quality = 1;
show_fps    = true;
in_menu     = true;
in_settings = false;
menu_sel    = 0;
anim_t      = 0;
lang        = "ru";

// Анимированные фигуры на фоне главного экрана
menu_pieces = [
    { x_frac: 0.12, y_frac: 0.24, sz: 18, spd: 1.4, phase: 0.0, col: c_aqua,   mat: [[1,1,1,1]] },
    { x_frac: 0.86, y_frac: 0.22, sz: 18, spd: 1.7, phase: 1.2, col: c_yellow, mat: [[1,1],[1,1]] },
    { x_frac: 0.16, y_frac: 0.72, sz: 18, spd: 1.2, phase: 2.4, col: c_purple, mat: [[0,1,0],[1,1,1]] },
    { x_frac: 0.84, y_frac: 0.74, sz: 18, spd: 1.5, phase: 3.6, col: c_lime,   mat: [[1,1,0],[0,1,1]] },
    { x_frac: 0.50, y_frac: 0.14, sz: 16, spd: 1.9, phase: 4.8, col: c_orange, mat: [[0,0,1],[1,1,1]] }
];

function tr(_ru, _en) {
    return (lang == "en") ? _en : _ru;
}

function apply_display_settings() {
    var _w = resolutions[res_index][0];
    var _h = resolutions[res_index][1];

    window_set_fullscreen(fullscreen);

    if (!fullscreen) {
        window_set_size(_w, _h);
        alarm[0] = 1;
    }

    surface_resize(application_surface, _w, _h);

    switch (gfx_quality) {
        case 0:
            gpu_set_texfilter(false);
            display_reset(0, false);
            break;
        case 1:
            gpu_set_texfilter(true);
            display_reset(0, false);
            break;
        case 2:
            gpu_set_texfilter(true);
            display_reset(4, false);
            break;
    }
}

apply_display_settings();

cols = 10;
rows = 20;
cell_size = 32;
grid = ds_grid_create(cols, rows);
ds_grid_clear(grid, 0);

max_level = 100;
level     = 1;
lines     = 0;
score     = 0;
medals    = [];
milestone_banner_num = 0;
milestone_timer      = 0;

shapes = [
    [[0,0,0,0],[1,1,1,1],[0,0,0,0],[0,0,0,0]],
    [[1,1,0,0],[1,1,0,0],[0,0,0,0],[0,0,0,0]],
    [[0,1,0,0],[1,1,1,0],[0,0,0,0],[0,0,0,0]],
    [[1,0,0,0],[1,1,1,0],[0,0,0,0],[0,0,0,0]],
    [[0,0,1,0],[1,1,1,0],[0,0,0,0],[0,0,0,0]],
    [[0,1,1,0],[1,1,0,0],[0,0,0,0],[0,0,0,0]],
    [[1,1,0,0],[0,1,1,0],[0,0,0,0],[0,0,0,0]]
];

cur_shape = [];
cur_color = 1;
cur_x = 3;
cur_y = 0;

drop_timer = 0;

function get_drop_interval(_lvl) {
    var _t = clamp((_lvl - 1) / (max_level - 1), 0, 1);
    return lerp(0.80, 0.05, _t);
}

function get_medal_name(_num) {
    return tr(string(_num) + "-й вех", "Milestone " + string(_num));
}

function spawn_piece() {
    var _idx = irandom(array_length(shapes) - 1);
    cur_shape = shapes[_idx];
    cur_color = _idx + 1;
    cur_x = (cols div 2) - 2;
    cur_y = 0;
}

function check_collision(_nx, _ny, _mat) {
    for (var _r = 0; _r < 4; _r++) {
        for (var _c = 0; _c < 4; _c++) {
            if (_mat[_r][_c] != 0) {
                var _gx = _nx + _c;
                var _gy = _ny + _r;
                if (_gx < 0 || _gx >= cols || _gy >= rows) return true;
                if (_gy >= 0 && grid[# _gx, _gy] != 0) return true;
            }
        }
    }
    return false;
}

function rotate_cw(_mat) {
    var _res = array_create(4);
    for (var _r = 0; _r < 4; _r++) {
        _res[_r] = array_create(4, 0);
        for (var _c = 0; _c < 4; _c++) {
            _res[_r][_c] = _mat[3 - _c][_r];
        }
    }
    return _res;
}

function award_milestone(_lvl) {
    if (_lvl > 0 && (_lvl mod 100 == 0)) {
        var _num = _lvl div 100;
        array_push(medals, _num);
        milestone_banner_num = _num;
        milestone_timer      = room_speed * 4;
    }
}

function add_lines(_cleared) {
    if (_cleared <= 0) return;

    lines += _cleared;
    var _pts = [0, 100, 300, 500, 800];
    score += _pts[_cleared] * level;

    var _new_level = min(max_level, 1 + (lines div 10));
    while (level < _new_level) {
        level++;
        award_milestone(level);
    }
}

spawn_piece();