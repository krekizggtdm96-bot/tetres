if (!fullscreen) {
    var _dw = display_get_width();
    var _dh = display_get_height();
    var _ww = window_get_width();
    var _wh = window_get_height();
    window_set_position((_dw - _ww) div 2, (_dh - _wh) div 2);
}