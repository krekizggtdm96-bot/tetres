if (variable_instance_exists(id, "fnt_main") && font_exists(fnt_main)) {
    draw_set_font(fnt_main);
}
draw_set_halign(fa_left);
draw_set_valign(fa_top);
draw_set_alpha(1);

var _gw = display_get_gui_width();
var _gh = display_get_gui_height();

if (variable_instance_exists(id, "spr_bg") && sprite_exists(spr_bg)) {
    draw_sprite_stretched(spr_bg, 0, 0, 0, _gw, _gh);
} else {
    draw_set_color(make_color_rgb(14, 18, 32));
    draw_rectangle(0, 0, _gw, _gh, false);

    var _grid_step = 48;
    var _scroll = (anim_t * 14) mod _grid_step;
    draw_set_color(make_color_rgb(24, 32, 54));
    for (var _gx = -_grid_step + _scroll; _gx < _gw; _gx += _grid_step) {
        draw_line(_gx, 0, _gx, _gh);
    }
    for (var _gy = -_grid_step + _scroll; _gy < _gh; _gy += _grid_step) {
        draw_line(0, _gy, _gw, _gy);
    }
}

if (in_menu && !in_settings) {
    for (var _p = 0; _p < array_length(menu_pieces); _p++) {
        var _item = menu_pieces[_p];
        var _sz = _item.sz;
        var _mat = _item.mat;
        var _rows_m = array_length(_mat);
        var _cols_m = array_length(_mat[0]);
        var _base_x = _gw * _item.x_frac + cos(anim_t * _item.spd * 0.7 + _item.phase) * 24;
        var _base_y = _gh * _item.y_frac + sin(anim_t * _item.spd + _item.phase) * 18;

        for (var _mr = 0; _mr < _rows_m; _mr++) {
            for (var _mc = 0; _mc < _cols_m; _mc++) {
                if (_mat[_mr][_mc] != 0) {
                    var _bx = _base_x + _mc * _sz;
                    var _by = _base_y + _mr * _sz;
                    draw_set_color(_item.col);
                    draw_rectangle(_bx, _by, _bx + _sz - 2, _by + _sz - 2, false);
                    draw_set_color(c_white);
                    draw_rectangle(_bx + 1, _by + 1, _bx + _sz - 3, _by + _sz - 3, true);
                }
            }
        }
    }

    var _pw = 460;
    var _ph = 330;
    var _px = (_gw - _pw) div 2;
    var _py = (_gh - _ph) div 2;

    draw_set_color(make_color_rgb(22, 28, 46));
    draw_rectangle(_px, _py, _px + _pw, _py + _ph, false);
    draw_set_color(c_aqua);
    draw_rectangle(_px, _py, _px + _pw, _py + _ph, true);

    if (variable_instance_exists(id, "spr_logo") && sprite_exists(spr_logo)) {
        var _lw = sprite_get_width(spr_logo);
        var _lh = sprite_get_height(spr_logo);
        var _logo_bob = sin(anim_t * 3) * 5;
        draw_sprite(spr_logo, 0, (_gw - _lw) div 2, max(8, _py - _lh - 8 + _logo_bob));
    }

    var _title = tr("ТЕТРИС — 100 УРОВНЕЙ", "TETRIS — 100 LEVELS");
    var _title_bob = sin(anim_t * 3.5) * 3;
    draw_set_color(c_aqua);
    draw_text((_gw - string_width(_title)) div 2, _py + 18 + _title_bob, _title);

    var _sub = tr("Классический тетрис до 100 уровня", "Classic Tetris up to level 100");
    draw_set_color(c_ltgray);
    draw_text((_gw - string_width(_sub)) div 2, _py + 42, _sub);

    var _items = [
        tr("Начать игру", "Start Game"),
        tr("Настройки", "Settings"),
        tr("Выход", "Exit")
    ];
    for (var _i = 0; _i < array_length(_items); _i++) {
        var _btn_w = 260;
        var _btn_h = 38;
        var _bx = (_gw - _btn_w) div 2;
        var _by = _py + 76 + _i * 48;
        var _sel = (menu_sel == _i);
        var _pulse = _sel ? (sin(anim_t * 7) * 3) : 0;

        draw_set_color(_sel ? make_color_rgb(45, 75, 120) : make_color_rgb(32, 40, 62));
        draw_rectangle(_bx - _pulse, _by, _bx + _btn_w + _pulse, _by + _btn_h, false);
        draw_set_color(_sel ? c_yellow : c_silver);
        draw_rectangle(_bx - _pulse, _by, _bx + _btn_w + _pulse, _by + _btn_h, true);

        var _label = (_sel ? "> " : "") + _items[_i];
        draw_set_color(_sel ? c_yellow : c_white);
        draw_text((_gw - string_width(_label)) div 2, _by + 11, _label);
    }

    var _ctrl = tr("Стрелки: ход/поворот/ускорение", "Arrows: move/rotate/drop");
    draw_set_color(c_silver);
    draw_text((_gw - string_width(_ctrl)) div 2, _py + 228, _ctrl);

    var _medal_info = tr("Медаль каждые 100 уровней", "Medal every 100 levels");
    draw_set_color(c_gold);
    draw_text((_gw - string_width(_medal_info)) div 2, _py + 252, _medal_info);

    var _hint = tr("Вверх/Вниз — выбор | Enter — открыть | L — язык", "Up/Down — select | Enter — open | L — lang");
    draw_set_color(c_ltgray);
    draw_text((_gw - string_width(_hint)) div 2, _py + _ph + 18, _hint);
} else if (!in_settings) {
    var _board_w = cols * cell_size;
    var _board_h = rows * cell_size;
    var _ox = (_gw - _board_w) div 2;
    var _oy = (_gh - _board_h) div 2;

    draw_set_color(c_dkgray);
    draw_rectangle(_ox - 4, _oy - 4, _ox + _board_w + 4, _oy + _board_h + 4, false);
    draw_set_color(make_color_rgb(10, 12, 20));
    draw_rectangle(_ox, _oy, _ox + _board_w, _oy + _board_h, false);

    var _palette = [c_black, c_aqua, c_yellow, c_purple, c_blue, c_orange, c_lime, c_red];

    for (var _r = 0; _r < rows; _r++) {
        for (var _c = 0; _c < cols; _c++) {
            var _val = grid[# _c, _r];
            var _x1 = _ox + _c * cell_size;
            var _y1 = _oy + _r * cell_size;

            if (_val > 0) {
                draw_set_color(_palette[_val]);
                draw_rectangle(_x1 + 1, _y1 + 1, _x1 + cell_size - 1, _y1 + cell_size - 1, false);
                if (gfx_quality >= 1) {
                    draw_set_color(c_white);
                    draw_rectangle(_x1 + 2, _y1 + 2, _x1 + cell_size - 2, _y1 + cell_size - 2, true);
                }
            } else if (gfx_quality == 2) {
                draw_set_color(make_color_rgb(25, 32, 48));
                draw_rectangle(_x1, _y1, _x1 + cell_size, _y1 + cell_size, true);
            }
        }
    }

    for (var _r = 0; _r < 4; _r++) {
        for (var _c = 0; _c < 4; _c++) {
            if (cur_shape[_r][_c] != 0) {
                var _x1 = _ox + (cur_x + _c) * cell_size;
                var _y1 = _oy + (cur_y + _r) * cell_size;
                draw_set_color(_palette[cur_color]);
                draw_rectangle(_x1 + 1, _y1 + 1, _x1 + cell_size - 1, _y1 + cell_size - 1, false);
            }
        }
    }

    var _ix = _ox + _board_w + 24;
    var _iy = _oy;
    draw_set_color(c_white);
    draw_text(_ix, _iy, tr("Очки: ", "Score: ") + string(score));
    draw_text(_ix, _iy + 24, tr("Уровень: ", "Level: ") + string(level) + " / " + string(max_level));
    draw_text(_ix, _iy + 48, tr("Линии: ", "Lines: ") + string(lines));
    draw_text(_ix, _iy + 84, tr("Медали (каждые 100 ур.):", "Medals (every 100 lvls):"));

    for (var _m = 0; _m < array_length(medals); _m++) {
        var _my_row = _iy + 110 + _m * 24;
        var _text_x = _ix;
        if (variable_instance_exists(id, "spr_medal") && sprite_exists(spr_medal)) {
            draw_sprite_stretched(spr_medal, 0, _ix, _my_row, 18, 18);
            _text_x = _ix + 24;
        }
        draw_set_color(c_gold);
        draw_text(_text_x, _my_row, "• " + get_medal_name(medals[_m]));
    }

    draw_set_color(c_ltgray);
    draw_text(_ix, _iy + _board_h - 48, tr("Стрелки: движение/поворот", "Arrows: move/rotate"));
    draw_text(_ix, _iy + _board_h - 24, tr("ESC / TAB: меню", "ESC / TAB: menu"));
}

if (in_menu || in_settings) {
    var _by_txt = "by xterr";
    draw_set_color(c_silver);
    draw_text((_gw - string_width(_by_txt)) div 2, _gh - 28, _by_txt);
}

if (show_fps) {
    draw_set_color(c_lime);
    draw_text(16, 16, "FPS: " + string(fps) + " (" + tr("реальный", "real") + ": " + string(round(fps_real)) + ")");
}

if (milestone_timer > 0) {
    var _banner = tr("МЕДАЛЬ ПОЛУЧЕНА: ", "MEDAL UNLOCKED: ") + get_medal_name(milestone_banner_num);
    draw_set_color(c_gold);
    draw_text((_gw - string_width(_banner)) div 2, 40, _banner);
}

if (in_settings) {
    var _mw = 520;
    var _mh = 270;
    var _mx = (_gw - _mw) div 2;
    var _my = (_gh - _mh) div 2;

    draw_set_color(make_color_rgb(22, 28, 46));
    draw_rectangle(_mx, _my, _mx + _mw, _my + _mh, false);
    draw_set_color(c_aqua);
    draw_rectangle(_mx, _my, _mx + _mw, _my + _mh, true);

    var _gfx_names = [
        tr("Низкая", "Low"),
        tr("Средняя", "Medium"),
        tr("Высокая", "High")
    ];
    var _res_str = string(resolutions[res_index][0]) + "x" + string(resolutions[res_index][1]);
    var _lang_str = (lang == "en") ? "English" : "Русский";

    draw_set_color(c_white);
    draw_text(_mx + 20, _my + 20, tr("НАСТРОЙКИ (ESC / TAB — назад)", "SETTINGS (ESC / TAB — back)"));
    draw_text(_mx + 20, _my + 55, tr("Разрешение (Влево/Вправо): ", "Resolution (Left/Right): ") + _res_str);
    draw_text(_mx + 20, _my + 85, tr("Полный экран (F): ", "Fullscreen (F): ") + (fullscreen ? tr("Да", "Yes") : tr("Нет", "No")));
    draw_text(_mx + 20, _my + 115, tr("Графика (Вверх/Вниз): ", "Graphics (Up/Down): ") + _gfx_names[gfx_quality]);
    draw_text(_mx + 20, _my + 145, tr("Счётчик FPS (H): ", "FPS Counter (H): ") + (show_fps ? tr("Вкл", "On") : tr("Выкл", "Off")));
    draw_text(_mx + 20, _my + 175, tr("Язык (L): ", "Language (L): ") + _lang_str);

    draw_set_color(c_ltgray);
    draw_text(_mx + 20, _my + 215, tr(
        "Нажмите ESC для возврата",
        "Press ESC to return"
    ));
}